<script>
    import { onMount } from 'svelte';
    let jsonInput = '';
    let responseData = {};
    let selectedOptions = [];
    let showError = false;

    async function handleSubmit() {
        try {
            showError = false;
            const response = await fetch('http://localhost:8000/bfhl', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ data: JSON.parse(jsonInput) })
            });

            if (!response.ok) {
                throw new Error('Network response was not ok');
            }

            responseData = await response.json();
        } catch (error) {
            showError = true;
            console.error('There was a problem with your fetch operation:', error);
        }
    }
</script>

<style>
    /* Add custom styles */
</style>

<h1>Your Roll Number</h1>
<input type="text" bind:value={jsonInput} placeholder="Enter JSON input" />
<button on:click={handleSubmit}>Submit</button>
{#if showError}
    <p>Error processing the request. Please check your input.</p>
{/if}
{#if Object.keys(responseData).length > 0}
    <select multiple bind:value={selectedOptions}>
        <option value="alphabets">Alphabets</option>
        <option value="numbers">Numbers</option>
        <option value="highest_lowercase_alphabet">Highest Lowercase Alphabet</option>
    </select>

    <div>
        {#if selectedOptions.includes('alphabets')}
            <p>Alphabets: {responseData.alphabets}</p>
        {/if}
        {#if selectedOptions.includes('numbers')}
            <p>Numbers: {responseData.numbers}</p>
        {/if}
        {#if selectedOptions.includes('highest_lowercase_alphabet')}
            <p>Highest Lowercase Alphabet: {responseData.highest_lowercase_alphabet}</p>
        {/if}
    </div>
{/if}
